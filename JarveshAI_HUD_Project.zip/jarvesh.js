
const tools = [
  { name: "TradingView", desc: "Real-time charts, indicators, and paper trading tools.", link: "https://www.tradingview.com/" },
  { name: "Groww App", desc: "Invest in mutual funds. Beginner friendly.", link: "https://groww.in/" },
  { name: "Zerodha", desc: "India’s #1 broker for serious traders.", link: "https://zerodha.com/" }
];

const container = document.getElementById("tools-panel");
const typingBox = document.getElementById("typingBox");

tools.forEach(tool => {
  const card = document.createElement("div");
  card.className = "tool-card";
  card.innerHTML = `<h3>${tool.name}</h3><p>${tool.desc}</p><a href="${tool.link}" target="_blank">🔗 Try Now</a>`;
  container.appendChild(card);
});

function typeMessage(text) {
  typingBox.innerHTML = "";
  let i = 0;
  const interval = setInterval(() => {
    if (i < text.length) {
      typingBox.innerHTML += text.charAt(i);
      i++;
    } else {
      clearInterval(interval);
    }
  }, 50);
}

function speak(text) {
  const synth = window.speechSynthesis;
  const utter = new SpeechSynthesisUtterance(text);
  utter.lang = "hi-IN";
  utter.pitch = 0.4;
  utter.rate = 0.9;
  utter.volume = 1;

  const voices = synth.getVoices();
  const best = voices.find(v => v.name.includes("Google") || v.name.includes("Microsoft"));
  if (best) utter.voice = best;

  synth.speak(utter);
  typeMessage(text);
}

document.getElementById("speak-btn").addEventListener("click", () => {
  speak("Main hoon Jarvesh. Aapke smart trading ke liye recommended tools hain TradingView, Groww aur Zerodha.");
});

document.getElementById("commandInput").addEventListener("keydown", function(e) {
  if (e.key === "Enter") {
    const input = e.target.value.toLowerCase();
    e.target.value = "";
    if (input.includes("best") || input.includes("trading")) {
      speak("Trading ke liye TradingView aur Zerodha best hain. Investing ke liye Groww app use karein.");
    } else if (input.includes("invest")) {
      speak("Groww app mutual funds aur beginners ke liye best hai.");
    } else {
      speak("Maaf kijiye, main samajh nahi paaya. Kripya trading ya investing se related poochhein.");
    }
  }
});

// Boot + Login logic
setTimeout(() => {
  document.getElementById("bootScreen").style.display = "none";
}, 4000);

document.getElementById("loginBtn").addEventListener("click", () => {
  const user = document.getElementById("username").value;
  const pass = document.getElementById("password").value;

  if (user === "pg" && pass === "123") {
    document.getElementById("loginScreen").style.display = "none";
    speak("Welcome Commander PGHW. Jarvesh Online.");
  } else {
    alert("Access Denied!");
  }
});
